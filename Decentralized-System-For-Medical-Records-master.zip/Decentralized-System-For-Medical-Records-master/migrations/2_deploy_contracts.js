const Login = artifacts.require("./Login.sol");

module.exports = function(deployer) {
  deployer.deploy(Login,"Nakul");
};
